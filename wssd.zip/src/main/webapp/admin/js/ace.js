jQuery.ace = {
		contextPath : null,
		
		setContextPath : function(path){
			contextPath = path;
		},
		
		getContextPath : function(){
			return contextPath;
		}
};